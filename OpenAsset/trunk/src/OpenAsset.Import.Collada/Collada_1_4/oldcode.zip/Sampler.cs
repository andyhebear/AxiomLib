﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OpenAsset.Import.Collada.Collada_1_4
{
    class Sampler
    {
        public string id;
        public List<InputLocal> input;

    }
}
