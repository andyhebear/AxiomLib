﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OpenAsset.Import.Collada.Collada_1_4
{
    class Source
    {
        public string id;
        public string name;
        public List<Asset> asset;
        public List<string> IDREF_array;
        public List<string> Name_array;
        public List<bool> Bool_array;
        public List<int> Int_array;
        public Assessor technique_common;
        public List<Technique> technique;
    }
}
