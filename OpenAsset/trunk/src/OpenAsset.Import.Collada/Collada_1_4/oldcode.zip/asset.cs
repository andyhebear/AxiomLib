﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OpenAsset.Import.Collada.Collada_1_4
{
    class Asset
    {
        public List<Contributor> contributor;
        public DateTime created;
        public List<string> keywords;
        public DateTime modified;
        public List<string> revision;
        public List<string> subject;
        public List<string> title;
        public List<Unit> unit;
        public UpAxisType up_axix;
    }
}
