﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OpenAsset.Import.Collada.Collada_1_4
{
    class Extra
    {
        public string id;
        public string name;
        public string type;
        public List<Asset> asset;
        public List<Technique> technique;
    }
}
