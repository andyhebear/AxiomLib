﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OpenAsset.Import.Collada.Collada_1_4
{
    class Contributor
    {
        public List<string> author;
        public List<string> authoringtool;
        public List<string> comments;
        public List<string> copyright;
        public List<Uri> sourcedata;
    }
}
