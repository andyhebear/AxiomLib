﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OpenAsset.Import.Collada.Collada_1_4
{
    class Technique
    {
        public string profile;
        public List<string> any;

    }
}
