﻿namespace OpenAsset.Import.Collada.Collada_1_4
{
    public enum UpAxisType
    {
        X_UP,
        Y_UP,
        Z_UP
    }
}