﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OpenAsset.Import.Collada.Collada_1_4
{
    class InputLocal
    {
        public string semantic;
        public string source;
    }
}
