﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OpenAsset.Import.Collada.Collada_1_4
{
    class Animation
    {
        public string id;
        public string name;
        public List<Asset> asset;
        public List<Source> source;
        public List<Sampler> sampler;
        public List<Channel> channel;
        public List<Animation> animation;
        public List<Extra> extra;
    }
}
