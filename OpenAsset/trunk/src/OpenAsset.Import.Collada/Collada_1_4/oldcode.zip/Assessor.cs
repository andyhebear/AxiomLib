﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OpenAsset.Import.Collada.Collada_1_4
{
    class Assessor
    {
        public uint count;
        public uint offset;
        public Uri source;
        public uint stride;
        public Param[] param;
    }
}
